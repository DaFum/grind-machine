/* SPDX-License-Identifier: GPL-3.0-only
 * Drum machine fork: 2026 DEADACTIVE */
/* Presets (spec docs/superpowers/specs/2026-10-19-presets-design.md): a factory preset is a voice, MODEL + the 8 SOUND
 * knobs P_E0..P_E7, nothing else (loading one leaves the track's FX, LFOs, LEVEL, PAN, NOTE, CHOKE, steps as they are).
 * A user preset (user decision 2026-11-01) is the voice and the track's FX but the SLICER: UPR_FX (sends, RESON, FILTER,
 * INSERT, SRR); not the SLICER, LAYER, LFOs / DEST slots, LEVEL, PAN, NOTE, CHOKE, PRIO, steps. One id for every
 * preset: the factory banks in order (MACHINEDRUM, MODERN, CLASSIC: const tables, preset_bank.h), then the 96 USER
 * slots (PRE_NFACT + slot). A track remembers the id it was loaded from (track_t.pre, PRE_NONE none) and whether a knob
 * the preset holds moved since (pre_ed: preset_marks, preset_touch); projects store both (project.c, FDRD: the
 * reference by a stable key, a factory preset's uid or a user slot, preset_rec_enc, never the positional id). The user
 * bank lives in RAM here; its flash record ("UPR2" in OBJ_UPRESET0 + 1, MIDI LEARN's map keeps OBJ_UPRESET0; an older
 * "UPR1" bank of 128 voices is moved into it at boot) is project.c's: preset_user_save / preset_user_delete (written at
 * once when stopped, at the next STOP while playing: preset_user_tick), preset_user_boot.
 * Included after dmodels.c (the model table) and before drum_core.c (drum_set_model: a voice's first preset). */
typedef struct { uint8_t model; int8_t k[8]; char name[9]; } preset_t;
#define PRE_NONE 0xFFFFu                                /* no preset (track_t.pre) */
#define PRE_NUSER 96u                                   /* user slots (128 before 2026-11-01: UPR1, UPR_NOLD) */
#define UPR_NOLD 128u                                   /* .. UPR1's slots (preset_user_boot moves them in) */
enum { PB_MD, PB_MODERN, PB_CLASSIC, PB_USER, PB_N };   /* (the order shown; MODERN before CLASSIC since fix 8: a
                                                          * project's reference is a uid, never an id or a bank) */
static const char *const N_PBANK[PB_N] = {"MACHINEDRUM", "MODERN", "CLASSIC", "USER"};
#include "preset_bank.h"
#define PRE_NID (PRE_NFACT + PRE_NUSER)                 /* ids 0 .. PRE_NID - 1 */
#define ACID_MAXTRK 2u                                  /* ACID is the model of 2 tracks at most (CPU), by user decision */

/* the FX a user preset holds, in the record's order (append only): every value fits a byte (params.c TP: -64..127;
 * tests/preset_test.c checks) */
#define UPR_NFX 23u
static const uint8_t UPR_FX[UPR_NFX] = {
    P_DIST, P_CHOR, P_DLY, P_REV,                                                   /* the sends */
    P_RMODEL, P_RTUNE, P_RDECAY, P_RMIX, P_RTONE, P_RSTRCT, P_RPOS, P_RKEY,         /* RESON */
    P_FTYPE, P_FCUT, P_FRESO, P_FENV, P_FDEC,                                       /* FILTER */
    P_ITYPE, P_IA, P_IB, P_IC, P_IMIX, P_SRR,                                       /* INSERT, SRR */
};
/* the user bank: the flash record's payload as it is (project.c), "UPR2", 3204 B. A slot: used UPR_USED (the voice
 * and its FX f[], UPR_FX's order), UPR_USED | UPR_VOICE (the voice only: moved from UPR1, it loads as a factory preset
 * does), else empty. mv: where UPR1's slots 97..128 moved (new slot + 1, 0 none / dropped): a project's reference to
 * one follows it (preset_rec_dec) */
#define UPR_USED 1u
#define UPR_VOICE 2u
typedef struct { uint8_t used, model; int8_t k[8]; int8_t f[UPR_NFX]; } upr_slot_t;
/* a SAMPLE preset's ATK SUS REL LOOP PLAY CUT (user decisions 2026-11-03 and for 1.0.0: the 96 slots kept, the
 * record's size too): 26 bits, each value's offset from its power-on value (ATK, SUS, REL 7 bits, LOOP 3, PLAY 1, CUT
 * 1), bits 0..22 in FX byte i (UPR_FX's order): the top bit of the 22 bytes whose values are 0..127, FILTER ENV's
 * (-64..63) its top bit unlike bit 6; bits 23, 24, 25 the top bit of SOUND knobs DRIVE's, DECAY's and TONE's bytes
 * (0..127 each). 0 = the defaults: such a slot is byte for byte as before; another model's slot never holds them.
 * upr_fxv reads an FX value out (a plain value too: the same), upr_knob a SOUND knob */
#define UPR_FENV 15u                                    /* UPR_FX's FILTER ENV */
static const uint8_t UPR_KBIT[3] = {3, 1, 2};          /* the SOUND knobs whose byte's top bit is bit 23 + j (DRIVE,
                                                        * DECAY, TONE: 0..127 each) */
static int upr_kbit(uint32_t i) { return i >= 1u && i <= 3u; }   /* (one of them) */
static int32_t upr_fxdec(int8_t f, uint32_t i)        /* FX byte i's value */
{
    uint32_t b = (uint8_t)f;
    return i == UPR_FENV ? (int32_t)((b & 0x7Fu) ^ 0x40u) - 0x40 : (int32_t)(b & 0x7Fu);
}
static int32_t upr_fxv(const upr_slot_t *s, uint32_t i) { return upr_fxdec(s->f[i], i); }
static uint32_t upr_fxbit(const upr_slot_t *s, uint32_t i)
{
    uint32_t b = (uint8_t)s->f[i];
    return (i == UPR_FENV ? b >> 7 ^ b >> 6 : b >> 7) & 1u;
}
static void upr_fxset(upr_slot_t *s, uint32_t i, int32_t v, uint32_t bit)
{
    uint32_t b = (uint32_t)(i == UPR_FENV ? clamp(v, -64, 63) : clamp(v, 0, 127)) & 0x7Fu;
    s->f[i] = (int8_t)(b | ((i == UPR_FENV ? (b >> 6 & 1u) ^ bit : bit) << 7));
}
static int32_t upr_knob(const upr_slot_t *s, uint32_t i)   /* SOUND knob i as stored (PLAY's bit off) */
{
    return s->model == DM_SMPL && upr_kbit(i) ? (int32_t)((uint8_t)s->k[i] & 0x7Fu) : s->k[i];
}
static uint32_t upr_env(const upr_slot_t *s)            /* the 26 bits (0: the defaults) */
{
    uint32_t e = 0, i;
    if (s->model != DM_SMPL)
        return 0;
    for (i = 0; i < UPR_NFX; i++)
        e |= upr_fxbit(s, i) << i;
    for (i = 0; i < 3u; i++)
        e |= (uint32_t)((uint8_t)s->k[UPR_KBIT[i]] >> 7) << (23u + i);
    return e;
}
/* ATK SUS REL LOOP PLAY CUT of p[] (a track's values) as the 26 bits; and back onto p[] (their power-on values and
 * ranges: params.c TP's, tests/sampenv_test.c checks) */
#define SENV_N 6u
static const uint8_t SENV_DEF[SENV_N] = {0, 0, 40, 0, 0, 0}, SENV_MAX[SENV_N] = {127, 127, 127, 4, 1, 1};
static const uint8_t SENV_SH[SENV_N] = {0, 7, 14, 21, 24, 25}, SENV_M[SENV_N] = {0x7F, 0x7F, 0x7F, 7, 1, 1};
static uint32_t senv_pack(const int16_t *p)
{
    uint32_t e = 0, i;
    for (i = 0; i < SENV_N; i++)
        e |= ((uint32_t)(p[P_SATK + i] - SENV_DEF[i]) & SENV_M[i]) << SENV_SH[i];
    return e;
}
static void senv_put(int16_t *p, uint32_t e)
{
    uint32_t i;
    for (i = 0; i < SENV_N; i++)
        p[P_SATK + i] = (int16_t)clamp((int32_t)((SENV_DEF[i] + (e >> SENV_SH[i])) & SENV_M[i]), 0, SENV_MAX[i]);
}
typedef char senv_ids[P_SPLAY == P_SATK + 4 && P_SCUT == P_SATK + 5 ? 1 : -1];
typedef struct { uint32_t magic; upr_slot_t s[PRE_NUSER]; uint8_t mv[UPR_NOLD - PRE_NUSER]; } upr_rec_t;
typedef char upr_rec_size[sizeof(upr_rec_t) == 4u + 33u * PRE_NUSER + 32u && sizeof(upr_rec_t) <= 3584u ? 1 : -1];
                                                        /* (one sector; below 3584: the loader's erase scan) */
typedef char pre_id_fits[PRE_NID < PRE_NONE ? 1 : -1];
#define UPR_MAGIC 0x32525055u                           /* "UPR2" */
#define UPR1_MAGIC 0x31525055u                          /* "UPR1": 128 slots {used, model, k[8]}, 1284 B */
#define UPR1_SIZE 1284u
#if defined(FELUCCA_BLE) && FELUCCA_BLE                 /* (the Bluetooth build: no .bss room; the RAM-code region's
                                                         * spare, as the variations' banks: persist_boot zeroes it) */
static upr_rec_t upr __attribute__((section(".ram_bss"), aligned(4)));
#else
static upr_rec_t upr;
#endif
static uint8_t upr_pending;                             /* changed while playing: written at the next STOP */

static void drum_cut(track_t *t);                       /* drum_core.c */
static const char *reson_refused(const track_t *t, int32_t from, int32_t to);   /* reson.c */
static uint32_t acid_tracks(const track_t *except);
static void motion_rebase(uint32_t k);                  /* motion.c */

/* a user slot's name: "<MODEL> NN", NN = slot + 1 (two digits, three from 100: then without the space when the
 * model's name has 5 characters: "SDTRX128") */
static void upr_name(char *d, uint32_t slot, uint32_t model)
{
    const char *m = N_MODEL[model % NMODELS];
    uint32_t n = 0, nn = slot + 1u;
    while (*m && n < 5u)
        d[n++] = *m++;
    if (nn < 100u || n < 5u)
        d[n++] = ' ';
    if (nn >= 100u)
        d[n++] = (char)('0' + nn / 100u);
    d[n++] = (char)('0' + nn / 10u % 10u);
    d[n++] = (char)('0' + nn % 10u);
    d[n] = 0;
}

static int upr_used(uint32_t slot)                      /* user slot holds a preset */
{
    uint32_t u = upr.s[slot % PRE_NUSER].used;
    return u == UPR_USED || u == (UPR_USED | UPR_VOICE);
}
/* preset id's FX (UPR_FX's order): a used user slot that holds them; 0 for a factory preset, an older user preset
 * (the voice only), an empty slot, a bad id */
static const int8_t *upr_fx(uint32_t id)
{
    if (id < PRE_NFACT || id >= PRE_NID || upr.s[id - PRE_NFACT].used != UPR_USED)
        return 0;
    return upr.s[id - PRE_NFACT].f;
}

/* preset id -> *out; 1, or 0 for an empty user slot or a bad id */
static int preset_get(uint32_t id, preset_t *out)
{
    uint32_t i;
    const upr_slot_t *s;
    if (id < PRE_NFACT) {
        *out = PRE_FACTORY[id];
        return 1;
    }
    if (id >= PRE_NID)
        return 0;
    s = &upr.s[id - PRE_NFACT];
    if (!upr_used(id - PRE_NFACT) || s->model >= NMODELS)
        return 0;
    out->model = s->model;
    for (i = 0; i < 8u; i++)
        out->k[i] = (int8_t)upr_knob(s, i);
    upr_name(out->name, id - PRE_NFACT, s->model);
    return 1;
}

/* the name shown for id (9 bytes): the preset's, "-" for none or an empty user slot */
static void preset_name_of(uint32_t id, char *out)
{
    preset_t p;
    uint32_t i;
    if (!preset_get(id, &p)) {
        out[0] = '-';
        out[1] = 0;
        return;
    }
    for (i = 0; i < 8u && p.name[i]; i++)
        out[i] = p.name[i];
    out[i] = 0;
}

/* t's preset as shown (the name on the SOUND pages and TRACKS, the list's mark and cursor): PRE_NONE for none, an
 * emptied user slot, or one now holding another voice than t's (never another voice's name on the track) */
static uint32_t preset_of(const track_t *t)
{
    preset_t p;
    if (!preset_get(t->pre, &p) || p.model != (uint32_t)t->p[P_MODEL])
        return PRE_NONE;
    return t->pre;
}

/* a project's preset reference (project.c, FDRD): stable across firmwares whose banks grow or are reordered, unlike the
 * ids (positions). A factory preset: its uid (PRE_UID, append-only: tools/gen_presets.py), 1..0x7FFF; a user slot:
 * PRE_REC_USER | slot (an older bank's slot 97..128: where it moved, upr.mv, none if dropped); none: PRE_NONE. The _in
 * forms take the bank's uids and size (tests: another firmware's) */
#define PRE_REC_USER 0x8000u
static uint32_t preset_rec_enc_in(uint32_t id, const uint16_t *uid, uint32_t nfact)
{
    if (id < nfact)
        return uid[id];
    if (id - nfact < PRE_NUSER)
        return PRE_REC_USER | (id - nfact);
    return PRE_NONE;
}
static uint32_t preset_rec_dec_in(uint32_t rec, const uint16_t *uid, uint32_t nfact)   /* PRE_NONE: unknown */
{
    uint32_t i;
    if (rec & PRE_REC_USER) {
        uint32_t s = rec & 0x7FFFu;
        if (s >= PRE_NUSER && s < UPR_NOLD)
            s = upr.mv[s - PRE_NUSER] - 1u;             /* (moved by the migration; 0: none, s wraps past the bank) */
        return s < PRE_NUSER ? nfact + s : PRE_NONE;
    }
    for (i = 0; rec && i < nfact; i++)
        if (uid[i] == rec)
            return i;
    return PRE_NONE;
}
static uint32_t preset_rec_enc(uint32_t id) { return preset_rec_enc_in(id, PRE_UID, PRE_NFACT); }
static uint32_t preset_rec_dec(uint32_t rec) { return preset_rec_dec_in(rec, PRE_UID, PRE_NFACT); }

static uint32_t preset_bank_of(uint32_t id)            /* PB_*, PB_N for a bad id */
{
    uint32_t b;
    for (b = 0; b < PB_N; b++)
        if (id >= PRE_BANK_START[b] && id < PRE_BANK_START[b + 1u])
            return b;
    return PB_N;
}

static uint32_t preset_first_of(uint32_t model)        /* the voice's first factory preset, PRE_NONE if none */
{
    uint32_t id;
    for (id = 0; id < PRE_NFACT; id++)
        if (PRE_FACTORY[id].model == model)
            return id;
    return PRE_NONE;
}

/* ---- the sample knobs stored before SLOT / START / END (dm_sample.c): a SLOT holding a KEY note, the SAMPLE model's
 * END its "-" knob's 0. smp_slot_conv: a KEY note of set -> its sample (the zone covering it, smp_find's; no zone: the
 * nearest), its pitch from the root moved into *tune (-24..24); kept as the note (which plays exactly as before) when
 * that does not fit, the root is not a whole note, or the set has no sample. Idempotent: a SLOT value stays */
static int32_t smp_slot_conv(uint32_t set, int32_t v, int32_t *tune)
{
    int32_t i = v >= 0 ? smp_slot_of(set, v) : -1, d16 = 0;
    uint32_t zi;
    if (i < 0)
        return v;
    zi = smp_find(set, (uint32_t)v);
    if (zi != 0xFFFFu) {                            /* (no zone there: the nearest, at its root) */
        d16 = v * 16 - smp_zone(zi)->root16;
        if ((d16 & 15) || *tune + d16 / 16 < -24 || *tune + d16 / 16 > 24)
            return v;
    }
    *tune += d16 / 16;
    return SMP_SLOT_V(i);
}
/* a stored knob value v of d, into its range; a SLOT's KEY note kept for smp_slot_conv, the SAMPLE END's 0 -> 127 */
static int32_t knob_in(const param_desc_t *d, int32_t v)
{
    if ((d->fmt == F_SLOT || d->fmt == F_LSLOT) && v >= 0)
        return v > 127 ? 127 : v;
    if (d == &DMODELS[DM_SMPL].edit[7] && v <= 0)
        return d->max;
    return clamp(v, d->min, d->max);
}
/* model m's knobs e[0..7] (P_E0..P_E7, through knob_in): a SAMPLE's KEY note converted, TUNE taking its pitch */
static void smpl_knobs_conv(int16_t *e, uint32_t m)
{
    int32_t tu = e[0];
    if (m % NMODELS != DM_SMPL)
        return;
    e[5] = (int16_t)smp_slot_conv((uint32_t)e[4], e[5], &tu);
    e[0] = (int16_t)tu;
}
static void layer_knobs_conv(int16_t *p)            /* a track's LAYER: its SLOT's KEY note, LAYER TUNE its pitch */
{
    int32_t tu = p[P_LTUNE];
    p[P_LKEY] = (int16_t)smp_slot_conv((uint32_t)p[P_LSET], p[P_LKEY], &tu);
    p[P_LTUNE] = (int16_t)tu;
}

/* knob id of t just set: a SET (the SAMPLE model's, the LAYER's) keeps its SLOT inside the new set's samples (a KEY
 * note: its sample in the new set). The IRQ off, or the ISR */
static void smp_set_moved(track_t *t, uint32_t id)
{
    uint32_t set = id == P_LSET ? (uint32_t)t->p[P_LSET] : (uint32_t)t->p[P_E4], sl = id == P_LSET ? P_LKEY : P_E5;
    int32_t i;
    if (id != P_LSET && (id != P_E4 || (uint32_t)t->p[P_MODEL] % NMODELS != DM_SMPL))
        return;
    i = smp_slot_of(set, t->p[sl]);
    t->p[sl] = (int16_t)SMP_SLOT_V(i < 0 ? 0 : i);
}

/* id is a preset t may load: not empty, not a third ACID track */
static int preset_ok(const track_t *t, uint32_t id, preset_t *p)
{
    return preset_get(id, p) && !(p->model == DM_ACID && acid_tracks(t) >= ACID_MAXTRK);
}

/* the voice of p on t: MODEL and the knobs (inside the model's ranges), the reference id, not edited. Another voice
 * cuts the old one first (as a MODEL change); the same voice is a knob turn */
static void preset_apply(track_t *t, const preset_t *p, uint32_t id)
{
    const dmodel_t *m = &DMODELS[p->model % NMODELS];
    uint32_t i;
    if ((uint32_t)t->p[P_MODEL] != p->model || t->model != p->model)
        drum_cut(t);
    t->p[P_MODEL] = (int16_t)(p->model % NMODELS);
    t->model = (uint8_t)t->p[P_MODEL];
    for (i = 0; i < 8u; i++)
        t->p[P_E0 + i] = (int16_t)knob_in(&m->edit[i], p->k[i]);
    smpl_knobs_conv(&t->p[P_E0], p->model);         /* (a SAMPLE preset stored before SLOT) */
    if (p->model % NMODELS == DM_SMPL)              /* its ATK SUS REL LOOP: a user one's, else the defaults */
        senv_put(t->p, id >= PRE_NFACT && id < PRE_NID ? upr_env(&upr.s[id - PRE_NFACT]) : 0u);
    t->pre = (uint16_t)id;
    t->pre_ed = 0;
}

/* FX f (UPR_FX's order) onto t, as their knobs turned (an INSERT TYPE fades, insert.c), after its voice and
 * motion_rebase (its locks let go, the knobs motion moved back): then motion's base again, the new values in it. RESON
 * MODEL within its caps, as a project load: CHORD / MODAL over theirs STRNG, RESON on 4 other tracks OFF. The IRQ off */
static void preset_fx_put(track_t *t, const int8_t *f)
{
    uint32_t i;
    for (i = 0; i < UPR_NFX; i++) {
        int32_t v = upr_fxdec(f[i], i);             /* (a slot's byte: ATK .. LOOP's bit off; a value: itself) */
        if (UPR_FX[i] == P_RMODEL) {
            if (reson_refused(t, t->p[P_RMODEL], v))
                v = RS_STRNG;
            if (reson_refused(t, t->p[P_RMODEL], v))
                v = RS_OFF;
        }
        t->p[UPR_FX[i]] = (int16_t)v;
    }
    motion_rebase((uint32_t)(t - trk));
}

/* load preset id onto t (the main loop: the audio IRQ off meanwhile, motion's base follows, as a MODEL change; CHOKE
 * and everything but the voice untouched, but a user preset's FX): 0, or -1 refused (an empty slot, a bad id, ACID on
 * ACID_MAXTRK others) */
static int preset_load(track_t *t, uint32_t id)
{
    preset_t p;
    const int8_t *f = upr_fx(id);
    if (!preset_ok(t, id, &p))
        return -1;
    fm1_irq_off();
    preset_apply(t, &p, id);
    motion_rebase((uint32_t)(t - trk));
    if (f)
        preset_fx_put(t, f);
    fm1_irq_on();
    return 0;
}

/* t's voice put back as it was (the PRESETS list's audition ended, ui_preset.c): MODEL, the 8 SOUND knobs k[0..7] and
 * ATK SUS REL LOOP PLAY k[8..12], the reference pre and its edited mark ed, as they were (no clamp), and FX f when the
 * audition changed them (0: as they are); the audio IRQ off, another voice cut first, motion's base follows, as
 * preset_load */
static void preset_put(track_t *t, uint32_t model, const int16_t *k, uint32_t pre, uint32_t ed, const int8_t *f)
{
    uint32_t i;
    fm1_irq_off();
    if ((uint32_t)t->p[P_MODEL] != model || t->model != model)
        drum_cut(t);
    t->p[P_MODEL] = (int16_t)(model % NMODELS);
    t->model = (uint8_t)t->p[P_MODEL];
    for (i = 0; i < 8u; i++)
        t->p[P_E0 + i] = k[i];
    for (i = 0; i < SENV_N; i++)
        t->p[P_SATK + i] = k[8u + i];
    t->pre = (uint16_t)pre;
    t->pre_ed = (uint8_t)ed;
    motion_rebase((uint32_t)(t - trk));
    if (f)
        preset_fx_put(t, f);
    fm1_irq_on();
}

/* the next (dir > 0) / previous loadable id from `from`, through every bank in order, wrapping (empty user slots and a
 * capped ACID skipped). No current preset (from out of range, PRE_NONE): the first preset of the track's voice */
static uint32_t preset_step(const track_t *t, uint32_t from, int dir)
{
    preset_t p;
    uint32_t id, n;
    if (from >= PRE_NID) {
        id = preset_first_of((uint32_t)t->p[P_MODEL]);
        if (id != PRE_NONE && preset_ok(t, id, &p))
            return id;
        from = dir > 0 ? PRE_NID - 1u : 0u;
    }
    if (!dir)
        return from;
    for (n = 0, id = from; n < PRE_NID; n++) {
        id = dir > 0 ? (id + 1u < PRE_NID ? id + 1u : 0u) : (id ? id - 1u : PRE_NID - 1u);
        if (preset_ok(t, id, &p))
            return id;
    }
    return from;
}

/* a user edit of what t's preset holds (a SOUND knob: the panel, MIDI LEARN, the SMC knobs; an FX knob as well when
 * the preset holds FX: preset_marks; not LFOs or MOTION playback) */
static void preset_touch(track_t *t) { t->pre_ed = 1; }
#define PRE_SOUND(id) ((uint32_t)(id) - P_E0 < 8u || (uint32_t)(id) - P_SATK < SENV_N)   /* a parameter id is a SOUND
                                                        * knob: the 8, SAMPLE's ATK SUS REL LOOP PLAY */
static int upr_fx_index(uint32_t id)                    /* id's place in UPR_FX, -1 not an FX a user preset holds */
{
    uint32_t i;
    for (i = 0; i < UPR_NFX; i++)
        if (UPR_FX[i] == id)
            return (int)i;
    return -1;
}
/* turning knob id marks t's preset edited: what loading it again would put back. The 8 SOUND knobs always; an FX knob
 * (UPR_FX) when t was loaded from a user preset that holds FX (a factory preset, an older user preset: the voice only;
 * the SLICER, LEVEL, ...: never) */
static int preset_marks(const track_t *t, uint32_t id)
{
    return PRE_SOUND(id) || (upr_fx_index(id) >= 0 && upr_fx(t->pre));
}

static int preset_user_free(void)                      /* the first free user slot, -1 none */
{
    uint32_t i;
    for (i = 0; i < PRE_NUSER; i++)
        if (!upr_used(i))
            return (int)i;
    return -1;
}

/* the user bank in RAM: slot <- a voice, model and the 8 SOUND knobs from kv[P_E0..P_E7], and the FX kv[UPR_FX] (a
 * track's p[], or motion's base while it plays: project.c preset_user_save; preset_user_delete empties one; both write
 * the flash) */
static void upr_set(uint32_t slot, uint32_t model, const int16_t *kv)
{
    upr_slot_t *s = &upr.s[slot];
    uint32_t i, e;
    s->used = UPR_USED;
    s->model = (uint8_t)(model % NMODELS);
    for (i = 0; i < 8u; i++)
        s->k[i] = (int8_t)clamp(kv[P_E0 + i], -128, 127);
    e = s->model == DM_SMPL ? senv_pack(kv) : 0u;   /* (another model: none) */
    for (i = 0; i < UPR_NFX; i++)
        upr_fxset(s, i, kv[UPR_FX[i]], e >> i & 1u);
    for (i = 0; i < 3u; i++)                        /* bits 23..25: DRIVE's, DECAY's, TONE's top bit (each 0..127) */
        if ((e >> (23u + i)) & 1u)
            s->k[UPR_KBIT[i]] = (int8_t)((uint8_t)clamp(s->k[UPR_KBIT[i]], 0, 127) | 0x80u);
}
