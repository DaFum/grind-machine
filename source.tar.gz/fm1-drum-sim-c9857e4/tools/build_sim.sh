#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-only
# Drum machine fork: 2026 DEADACTIVE
# The web simulator (docs/SIMULATOR.md): generated headers, the headless host test, the wasm (emscripten in
# Docker), the page, the node glue test. Everything is written under build/sim/.
#   tools/build_sim.sh                  the firmware in this checkout
#   tools/build_sim.sh --ref main       the firmware of a commit / branch (exported into build/sim/src, with this
#                                       checkout's simulator files laid over it; no branch is touched)
#   tools/build_sim.sh --host-only      generated headers + host test only (no Docker, no node); combines with --ref
#   tools/build_sim.sh --preview        also build/sim/preview/: the site's layout (the landing page at /, the installer
#                                       at webapp/installer/, assembled as web/make_site.py does, with no firmware
#                                       package: it shows "could not load" and cannot install)
#   tools/build_sim.sh --ref main --preview --package FILE.fwsc
#                                       the preview with a firmware package already built (tools/build.py,
#                                       DRUM_PACKAGE=1): copied in, the site assembled by make_site.py; its installer
#                                       can flash an FM-1
set -euo pipefail
cd "$(dirname "$0")/.."
PY=${PYTHON:-python3}
export PYTHONDONTWRITEBYTECODE=1                      # no __pycache__ next to tools/build.py: output stays in build/sim
OUT=build/sim
GEN=$OUT/gen
HOST_ONLY=0 REF= PREVIEW=0 PACKAGE=
while [ $# -gt 0 ]; do
    case "$1" in
        --host-only) HOST_ONLY=1 ;;
        --preview) PREVIEW=1 ;;
        --package) PACKAGE=${2:?--package needs a .fwsc file}; shift ;;
        --ref) REF=${2:?--ref needs a commit or branch}; shift ;;
        *) echo "build_sim: unknown option $1" >&2; exit 2 ;;
    esac
    shift
done
mkdir -p "$GEN" "$OUT/host"
if [ -n "$PACKAGE" ] && { [ "$PREVIEW" = 0 ] || [ ! -f "$PACKAGE" ]; }; then
    echo "build_sim: --package needs --preview and an existing .fwsc ($PACKAGE)" >&2
    exit 2
fi

# 0. the source root: this checkout, or REF's tree with the simulator's files (tests/sim_*, web/sim) laid over it
ROOT=.
if [ -n "$REF" ]; then
    ROOT=$OUT/src
    rm -rf "$ROOT"
    mkdir -p "$ROOT"
    git archive "$REF" | tar -x -C "$ROOT"
    cp tests/sim_* "$ROOT/tests/"
    cp web/index_pkg.html web/make_site.py "$ROOT/web/"  # use this simulator's site assembly with the ref's editor
    mkdir -p "$ROOT/web/sim" "$ROOT/tools" "$ROOT/docs"
    cp web/sim/* "$ROOT/web/sim/"
    cp tools/build_sim.sh "$ROOT/tools/"
    cp docs/SIMULATOR.md "$ROOT/docs/"
    echo "build_sim: firmware from $REF ($(git rev-parse --short "$REF")), simulator from $(git rev-parse --short HEAD)"
fi
VERSION=$(cat "$ROOT/VERSION.txt" 2>/dev/null || echo DEV)
DEFS=(-DFELUCCA_VERSION="\"DRUM-$VERSION\"")         # ABOUT shows the firmware's version, as tools/build.py does
NATIVE=0
if [ "${GRIND_NATIVE:-0}" = 1 ]; then
    NATIVE=1
    DEFS+=(-DGRIND_NATIVE=1)                        # the Grind engine and its GRIND pages (off by default)
fi

# the landing page's version line and "what's new": VERSION.txt, the commit, CHANGELOG.md's Unreleased and this version
"$PY" - "$ROOT/CHANGELOG.md" "$VERSION" "$(git rev-parse --short "${REF:-HEAD}")" "$(git log -1 --format=%cs "${REF:-HEAD}")" "$NATIVE" \
    > "$OUT/version.json" <<'PY'
import json, re, sys
from pathlib import Path
log, version, commit, date = Path(sys.argv[1]), sys.argv[2], sys.argv[3], sys.argv[4]
sections, cur = {}, None
for line in (log.read_text(encoding="utf-8").splitlines() if log.exists() else []):
    m = re.match(r"## (Unreleased|(\d+\.\d+\.\d+) - (\d{4}-\d{2}-\d{2}))\s*$", line)
    if m:
        cur = sections.setdefault(m[2] or "Unreleased", {"date": m[3], "notes": []})
    elif cur is not None and line.startswith("- "):
        cur["notes"].append(line[2:].strip())
    elif cur is not None and line.startswith("  ") and cur["notes"]:
        cur["notes"][-1] += " " + line.strip()
def note(text):                                   # a short title: the words before the first colon or bracket
    text = text.replace("`", "").replace("**", "")      # plain text: no code marks, no bold
    head = re.split(r"[:(]", text, maxsplit=1)[0].strip()
    title = head if 0 < len(head) <= 48 else " ".join(text.split()[:5])
    return {"title": title, "text": text}
rel = sections.get(version, {"date": None, "notes": []})
print(json.dumps({"version": version, "commit": commit, "date": date, "grind_native": sys.argv[5] == "1",
                  "since": [note(n) for n in sections.get("Unreleased", {"notes": []})["notes"]],
                  "release": {"version": version, "date": rel["date"], "notes": [note(n) for n in rel["notes"]]}}, indent=1))
PY

# 1. generated headers (tools/build.py's list, written into build/sim/gen) and the input matrix keymap
"$PY" -c 'import sys; sys.path.insert(0, sys.argv[2] + "/tools"); import build; from pathlib import Path; build.GEN = Path(sys.argv[1]).resolve(); build.generate()' "$GEN" "$ROOT" >/dev/null
awk '/static const int8_t FM1_KEYMAP/,/^};/' "$ROOT/firmware/hal/fm1_input.h" > "$GEN/sim_keymap.h"
grep -q FM1_KEYMAP "$GEN/sim_keymap.h" || { echo "build_sim: FM1_KEYMAP not found in firmware/hal/fm1_input.h" >&2; exit 1; }

# 2. host test: the sim core in plain cc, same sources (run from the source root: it reads felucca.c)
CFLAGS=(-O2 -Wall -Wno-unused-function -Wno-int-to-pointer-cast -Wno-macro-redefined -I"$GEN" -I"$ROOT/firmware/src" -I"$ROOT/tests")
cc "${CFLAGS[@]}" "${DEFS[@]}" -o "$OUT/host/sim_test" "$ROOT/tests/sim_test.c" -lm
TEST_BIN=$PWD/$OUT/host/sim_test
(cd "$ROOT" && "$TEST_BIN")
# the landing page's lab (the feature pieces): what each computes, on the firmware's own DSP
cc "${CFLAGS[@]}" "${DEFS[@]}" -o "$OUT/host/sim_lab_test" "$ROOT/tests/sim_lab_test.c" -lm
"$OUT/host/sim_lab_test"
cc "${CFLAGS[@]}" "${DEFS[@]}" -o "$OUT/host/sim_ids" "$ROOT/tests/sim_ids.c" -lm
"$OUT/host/sim_ids" > "$OUT/lab_ids.json"                 # the firmware's ids for web/sim/lab.js
# the landing page's reel: the same core, a scripted performance recorded (tests/sim_record.c)
cc "${CFLAGS[@]}" "${DEFS[@]}" -o "$OUT/host/sim_record" "$ROOT/tests/sim_record.c" -lm
"$OUT/host/sim_record" "$OUT/reel.bin" "$OUT/reel.hash" "$OUT/reel.json"
gzip -9 -n -f -k "$OUT/reel.bin"
# the page's typeface: the firmware's own Terminus as a web font (tests/sim_font.mjs), with its licence
node "$ROOT/tests/sim_font.mjs" "$ROOT/assets/fonts/ter-u16n.bdf" "$OUT/terminus.woff"
node "$ROOT/tests/sim_boot_preview.mjs"                          # the ?boot=1 scene preview controller (fake clock)
cp "$ROOT/assets/fonts/Terminus-LICENSE.txt" "$OUT/terminus-license.txt"
# the features' reel: each chapter's page with its knobs turned to their ends (tests/sim_feature_reel.c)
cc "${CFLAGS[@]}" "${DEFS[@]}" -o "$OUT/host/sim_feature_reel" "$ROOT/tests/sim_feature_reel.c" -lm
"$OUT/host/sim_feature_reel" "$OUT/features.bin" "$OUT/features.json"
gzip -9 -n -f -k "$OUT/features.bin"

[ "$HOST_ONLY" = 1 ] && exit 0

# 3. wasm: emscripten in Docker (pinned), the same sim core, no JS glue (web/sim/engine.js loads it)
IMG=emscripten/emsdk:6.0.11
if ! docker info >/dev/null 2>&1; then
    [ "$(uname)" = Darwin ] && open -a Docker
    for _ in $(seq 60); do docker info >/dev/null 2>&1 && break; sleep 1; done
fi
EXPORTS=_sim_init,_sim_render,_sim_frame,_sim_btn,_sim_key,_sim_enc,_sim_master,_sim_leds,_sim_key_leds,_sim_fb,_sim_audio,_sim_flash
EXPORTS=$EXPORTS,_sim_flash_reset,_sim_flash_dirty,_sim_flash_clean,_sim_playing,_sim_boot_preview
EXPORTS=$EXPORTS,_lab_reset,_lab_model,_lab_param,_lab_global,_lab_step,_lab_play,_lab_hit,_lab_perf,_lab_watch,_lab_mute,_lab_motion,_lab_knob,_lab_motion_clear,_lab_select,_lab_render_mono
EXPORTS=$EXPORTS,_lab_note,_lab_voice,_lab_grids,_lab_buf,_lab_probes,_lab_probe_count,_lab_probe_clear,_lab_probe_size
docker run --rm -v "$PWD":/src -w /src -u "$(id -u):$(id -g)" -e EM_CACHE=/src/$OUT/emcache "$IMG" \
    emcc -O2 -sSTANDALONE_WASM --no-entry -sINITIAL_MEMORY=8MB -sSTACK_SIZE=256KB -sEXPORTED_FUNCTIONS="$EXPORTS" \
    -Wno-unused-function -Wno-int-to-pointer-cast -Wno-macro-redefined "${DEFS[@]}" \
    -I"$GEN" -I"$ROOT/firmware/src" -I"$ROOT/tests" -o "$OUT/fm1sim.wasm" "$ROOT/tests/sim_core.c"

# 4. the page next to it, with the source it was built from (GPL-3.0: the page links source.tar.gz), then the glue
#    test on the built wasm
cp "$ROOT"/web/sim/* "$OUT/"
PAGE=$(cd "$ROOT/web/sim" && ls)                       # the page's own files (the preview copies the stamped ones)
if [ -n "$REF" ]; then
    (cd "$OUT" && tar -czf source.tar.gz src)
else
    git archive --format=tar.gz --prefix="fm1-drum-sim-$(git rev-parse --short HEAD)/" -o "$OUT/source.tar.gz" HEAD
fi
[ -n "$REF" ] || [ -z "$(git status --porcelain -- firmware tests web tools)" ] ||
    echo "build_sim: uncommitted changes: source.tar.gz is HEAD, not this build (commit before publishing)" >&2
# stamp every local reference with a hash of what is published (?v=): after an update, browsers never mix cached old
# files with new ones (app.js of one build, layout.js of another)
"$PY" - "$OUT" $PAGE fm1sim.wasm reel.bin.gz reel.json features.bin.gz features.json terminus.woff terminus-license.txt version.json lab_ids.json source.tar.gz <<'PY'
import hashlib, sys
from pathlib import Path
out, names = Path(sys.argv[1]), sys.argv[2:]
h = hashlib.sha1()
for n in sorted(names):
    if (out / n).exists():
        h.update(n.encode()); h.update((out / n).read_bytes())
stamp = h.hexdigest()[:10]
for n in names:
    f = out / n
    if f.suffix not in (".html", ".js", ".css") or not f.exists():
        continue
    t = f.read_text(encoding="utf-8")
    for m in names:
        for q in ("'", '"'):
            t = t.replace(f"{q}./{m}{q}", f"{q}./{m}?v={stamp}{q}").replace(f"{q}{m}{q}", f"{q}{m}?v={stamp}{q}")
    f.write_text(t, encoding="utf-8")
print(f"build_sim: page stamped ?v={stamp}")
PY
OUT_ABS=$PWD/$OUT
(cd "$ROOT" && node --test-reporter=dot tests/sim_glue.mjs "$OUT_ABS" && node --test-reporter=dot tests/sim_site.mjs)

# 5. The stand-alone simulator links to an installer without a package. A packaged preview gets its own installer.
mkdir -p "$OUT/webapp/installer"
"$PY" - "$ROOT/web" "$OUT/webapp/installer/index.html" "$VERSION" <<'PY'
import json, sys
from pathlib import Path
web, out, version = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
sys.path.insert(0, str(web))
from make_site import LIB, strip_module
html = (web / "index_pkg.html").read_text(encoding="utf-8").replace(
    'href="../editor/"', 'href="https://dafum.github.io/grind-machine/webapp/editor/"'
)
lib = "\n".join(strip_module((web / f).read_text(encoding="utf-8")) for f in LIB)
meta = json.dumps({"version": version + " (preview)", "product": "FM-1_984", "pkg": "../../firmware/preview-has-no-package.fwsc"})
out.write_text(html.replace("/*LIB*/", lib).replace("/*META*/", meta), encoding="utf-8")
PY
if [ "$PREVIEW" = 1 ]; then
    P=$OUT/preview
    rm -rf "$P"
    mkdir -p "$P/webapp/installer"
    if [ -n "$PACKAGE" ]; then
        cp "$PACKAGE" "$OUT/package.fwsc"                 # a copy: the original is never touched
        LABEL=$(basename "$PACKAGE" .fwsc | sed -nE 's/^felucca-((drum|hortator)-[0-9.]+)-([0-9a-f]+(-dirty)?)$/\1+\3/p')
        LABEL=${LABEL:-drum-$VERSION}
        echo "build_sim: preview with the firmware package $(basename "$PACKAGE") ($LABEL)"
        "$PY" - "$ROOT/web" "$OUT/package.fwsc" "$LABEL" "$P" "$OUT" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
import make_site                                     # the site exactly as web/make_site.py makes it
make_site.main(*sys.argv[2:5], sim_dir=sys.argv[5])
PY
    else
        cp "$OUT/webapp/installer/index.html" "$P/webapp/installer/"
        for f in $PAGE fm1sim.wasm source.tar.gz reel.bin.gz reel.json features.bin.gz features.json terminus.woff terminus-license.txt version.json lab_ids.json; do cp "$OUT/$f" "$P/"; done   # the landing page at /
    fi
    echo "build_sim: preview $P (cd $P && python3 -m http.server 8001)"
fi
echo "build_sim: $OUT ready, firmware DRUM-$VERSION (cd $OUT && python3 -m http.server 8001)"
