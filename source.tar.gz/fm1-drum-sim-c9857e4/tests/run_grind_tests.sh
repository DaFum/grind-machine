#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
set -eu
cd "$(dirname "$0")/.."

WASM=${GRIND_WASM:-0}
if [ "$WASM" = 1 ]; then
    CC=${CC:-emcc}
    OUT=build/grind-wasm
else
    CC=${CC:-cc}
    OUT=build/grind-host
fi
CFLAGS="-std=c99 -O1 -g -Wall -Wextra -Werror -UNDEBUG ${GRIND_SAN_FLAGS:-}"
CORE=firmware/src/grind
mkdir -p "$OUT"

run_test() {
    suite=$1
    shift
    if [ "$WASM" = 1 ]; then
        case "$suite" in
            rng) set -- "$@" --embed-file tests/grind/golden/rng-v1.txt@/tests/grind/golden/rng-v1.txt ;;
            rules) set -- "$@" --embed-file tests/grind/golden/styles-v1.csv@/tests/grind/golden/styles-v1.csv ;;
            golden) set -- "$@" --embed-file tests/grind/golden/patterns-v1.bin@/tests/grind/golden/patterns-v1.bin ;;
        esac
        $CC $CFLAGS -sEXIT_RUNTIME=1 -sSTACK_SIZE=256KB -I"$CORE" "tests/grind/test_$suite.c" "$@" -o "$OUT/test_$suite.js"
        "${NODE:-node}" "$OUT/test_$suite.js"
    else
        $CC $CFLAGS -I"$CORE" "tests/grind/test_$suite.c" "$@" -o "$OUT/test_$suite"
        "$OUT/test_$suite"
    fi
}

run_rng() {
    "${PYTHON:-python3}" tools/grind/rng_reference.py > "$OUT/rng-reference.txt"
    cmp tests/grind/golden/rng-v1.txt "$OUT/rng-reference.txt"
    run_test rng "$CORE/rng.c"
}

run_pattern_test() {
    run_test "$1" "$CORE/grid.c" "$CORE/rules.c" "$CORE/core.c" "$CORE/locks.c" \
        "$CORE/rng.c" "$CORE/serialize.c"
}

run_golden() {
    "${PYTHON:-python3}" tools/grind/check_vectors.py
    run_pattern_test golden
}

# The native adapter suites compile the real firmware sources (tests/drum_host.h) with the upstream host flags,
# including its sanitizer exception: the firmware's fixed-point code shifts negative values left.
run_native() {
    suite=$1
    [ "$WASM" = 1 ] && { echo "$suite: native fixture is host-only" >&2; return 0; }
    "${PYTHON:-python3}" tools/build.py --gen-only > /dev/null
    $CC -std=gnu11 -O1 -g -Wall -Wno-unused-function -Wno-int-to-pointer-cast -Wno-macro-redefined -Wno-date-time         ${GRIND_SAN_FLAGS:+${GRIND_SAN_FLAGS} -fno-sanitize=shift-base} -UNDEBUG -Ibuild/gen -Ifirmware/src -Itests -I"$CORE"         "tests/grind/test_$suite.c" -o "$OUT/test_$suite" -lm
    "$OUT/test_$suite"
}

run_boot_native() {
    suite=$1
    [ "$WASM" = 1 ] && { echo "$suite: native fixture is host-only"; return 0; }
    "${PYTHON:-python3}" tools/build.py --gen-only > /dev/null
    for native in 0 1; do
        $CC -std=gnu11 -O1 -g -Wall -Wno-unused-function -Wno-int-to-pointer-cast -Wno-macro-redefined -Wno-date-time ${GRIND_SAN_FLAGS:+${GRIND_SAN_FLAGS} -fno-sanitize=shift-base} -UNDEBUG -DGRIND_NATIVE="$native" -DGRIND_BOOT_LCD_ASSERT=1 -Ibuild/gen -Ifirmware/src -Itests -I"$CORE" "tests/grind/test_$suite.c" -o "$OUT/test_${suite}_$native" -lm
        "$OUT/test_${suite}_$native"
    done
}

run_boot_existing() {
    suite=$1
    boot_source=$2
    [ "$WASM" = 1 ] && { echo "$suite: native fixture is host-only"; return 0; }
    "${PYTHON:-python3}" tools/build.py --gen-only > /dev/null
    mkdir -p build/ui_shots/fixes build/ui_shots/themes   # (the upstream fixtures write screenshots)
    $CC -std=gnu11 -O1 -g -Wall -Wno-unused-function -Wno-int-to-pointer-cast         -Wno-macro-redefined -Wno-date-time         ${GRIND_SAN_FLAGS:+${GRIND_SAN_FLAGS} -fno-sanitize=shift-base}         -UNDEBUG -DGRIND_NATIVE=1 -Ibuild/gen -Ifirmware/src -Itests -I"$CORE"         "$boot_source" -o "$OUT/test_$suite" -lm
    "$OUT/test_$suite"
}

run_grind_editor() {
    [ "$WASM" = 1 ] && return 0
    "${PYTHON:-python3}" tools/build.py --gen-only > /dev/null
    $CC -DGRIND_NATIVE=1 -std=gnu11 -O1 -g -Wno-int-to-pointer-cast \
        -Ibuild/gen -Ifirmware/src tests/editor_test.c -o "$OUT/test_editor" -lm
    "$OUT/test_editor"
}

case "${1:-all}" in
    editor) run_grind_editor ;;
    adapter) run_native adapter ;;
    cue) run_native cue ;;
    ui) run_native ui ;;
    vary) run_native vary ;;
    be_runtime) run_native be_runtime ;;
    be_ui) run_native be_ui ;;
    master_fx) run_native master_fx ;;
    persist) run_native persist ;;
    menu) run_native menu ;;
    controller) run_test controller "$CORE/controller.c" "$CORE/grid.c" "$CORE/rules.c" "$CORE/core.c" "$CORE/locks.c" \
        "$CORE/rng.c" "$CORE/serialize.c" ;;
    be_layers) run_test be_layers "$CORE/be_layers.c" "$CORE/be_math.c" "$CORE/grid.c" "$CORE/rules.c" "$CORE/core.c" \
        "$CORE/locks.c" "$CORE/rng.c" "$CORE/serialize.c" ;;
    grid) run_test grid "$CORE/grid.c" ;;
    boot_anim) run_test boot_anim "$CORE/boot_anim.c" ;;
    boot_draw) run_boot_native boot_draw ;;
    boot_ui) run_boot_native boot_ui ;;
    boot_recovery) run_boot_existing boot_recovery tests/boot_test.c ;;
    boot_restore) run_boot_existing boot_restore tests/editor_backup_test.c ;;
    hit_variation) run_test hit_variation ;;
    rng) run_rng ;;
    codec) run_test codec "$CORE/serialize.c" "$CORE/grid.c" ;;
    rules) run_test rules "$CORE/rules.c" "$CORE/grid.c" ;;
    locks) run_test locks "$CORE/locks.c" ;;
    morph|properties) run_pattern_test "$1" ;;
    golden) run_golden ;;
    all)
        run_test grid "$CORE/grid.c"
        run_test be_layers "$CORE/be_layers.c" "$CORE/be_math.c" "$CORE/grid.c" "$CORE/rules.c" "$CORE/core.c" \
            "$CORE/locks.c" "$CORE/rng.c" "$CORE/serialize.c"
        run_test boot_anim "$CORE/boot_anim.c"
        run_test hit_variation
        run_rng
        run_test codec "$CORE/serialize.c" "$CORE/grid.c"
        run_test rules "$CORE/rules.c" "$CORE/grid.c"
        run_test locks "$CORE/locks.c"
        run_pattern_test morph
        run_pattern_test properties
        run_golden
        run_test controller "$CORE/controller.c" "$CORE/grid.c" "$CORE/rules.c" "$CORE/core.c" "$CORE/locks.c" \
            "$CORE/rng.c" "$CORE/serialize.c"
        run_native adapter
        run_native cue
        run_native ui
        run_native vary
        run_native be_runtime
        run_native be_ui
        run_native master_fx
        run_native persist
        run_native menu
        run_boot_native boot_draw
        run_boot_native boot_ui
        run_boot_existing boot_recovery tests/boot_test.c
        run_boot_existing boot_restore tests/editor_backup_test.c
        run_grind_editor
        ;;
    *) echo "unknown suite: $1" >&2; exit 2 ;;
esac
