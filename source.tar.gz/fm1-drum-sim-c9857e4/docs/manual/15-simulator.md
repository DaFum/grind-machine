# Web simulator
<!--blurb: Playing GRIND MACHINE in the browser with mouse, touch and computer keyboard.-->

## What it is

The local **GRIND MACHINE simulator** runs the firmware compiled to WebAssembly. The FM-1 panel includes the 240 × 240 screen, buttons, keys, knobs, LEDs and stereo audio. Build with `GRIND_NATIVE=1` and press ARP through the two GRIDS pages to reach GRIND. A fresh browser store includes MATH 7/4 in demo slot D. The simulator uses the standard non-Bluetooth build and labels SCL as SEL.

The page also has a short guide for each area, and interactive pieces that run the firmware's own DSP: voices, resonators, the compressor, LFOs, the sequencer's chance and live hands, Grids, effects and PERFORM.

## Start screen preview (GRIND builds)

The Preview BLAST IGNITION link opens a read-only tab at `?boot=1#play`. The 400 ms scene uses the firmware's C renderer
in a separate instance. Power and Reset to demos are disabled, and the tab leaves browser saves alone. With reduced
motion enabled, the scene shows the final READY frame. Escape returns to the demo reel. A build without the GRIND
engine shows the reel from the start.

On the device, the static title appears during initialisation. The scene follows on the first normal screen. Input
cancels it and acts normally, and the boot's LOADED note keeps its full display time.

## Storage

The simulator's flash lives in your browser (IndexedDB). Anything you save with SAVE stays there; as on the device, the last project saved loads at power-on. With no project remembered the demos are loaded into the slots. **Reset to demos** on the page clears the store. A browser that blocks storage still runs the simulator, with saves lasting only for the session.

## Mouse and touch

- Keys and buttons sound while held; multi-touch works.
- Knobs: drag up or down (12 px per detent), use the mouse wheel, or hover a knob and press the up and down arrow keys.
- MASTER is a pot (0 to 1023, default 800).
- To hold a button for a combination (SEQ held plus a key, OCT- held in TRACKS), **right-click** it or **long-press** it for 600 ms. A dashed outline shows it is held; tap it again to let go.

## Computer keyboard

By physical key, on any layout:

| Keys | Plays |
| --- | --- |
| `Z X C V B N M , . /` | white keys F3 to A4 |
| `S D F H J L ; '` | black keys F#3 G#3 A#3 C#4 D#4 F#4 G#4 A#4 |
| `Q W E R T Y` | white keys B4 to G5 |
| `3 4 6` | C#5 D#5 F#5 |
| Space | PLAY |
| Enter | REC |
| Esc | HOME |
| Left / Right arrow | OCT- / OCT+ |

Autorepeat and shortcuts with Cmd, Ctrl or Alt are ignored. Leaving the tab releases everything held.

## Building and testing it

`GRIND_NATIVE=1 bash tools/build_sim.sh --preview` builds the GRIND simulator into `build/sim/preview/`. It needs Docker, Node 18 or newer, Python 3 with Pillow and a C compiler. The published GRIND preview site provides the installer and editor. See `docs/SIMULATOR.md` for the local browser setup.

## This manual

This manual is a single page built by `tools/build_manual.py` from the section files in `docs/manual/`. `web/make_site.py` publishes it at `/manual/` on the site. Search is entirely in the page.
